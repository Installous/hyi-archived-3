var Lang = "en"; // (fr) for French, (de) for German, (es) for Spanish, (it) for Italian, (en) for English
var Clock = "12"; // 12 or 24
var locale = "ukxx0085"; // Here your weather code from weather.com,if have problem contact me
var Temp = "c"; // c for Celsius, f for Fahrenheit
var updateInterval = 5; // choose the minutes for refresh automatically
var iconSet = "BlackHTC"; // BlackHTC, Yahoo, StyleiOS7 choose you :)
var iconExt = ".png"; // icon extension, don't touch here,all icons in description are .png
var useRealFeel = false; // true or false
