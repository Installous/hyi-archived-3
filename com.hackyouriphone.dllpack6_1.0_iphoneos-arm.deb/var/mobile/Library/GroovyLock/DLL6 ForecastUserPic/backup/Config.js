var lang = "en"; // (fr) for French, (de) for German, (es) for Spanish, (it) for Italian, (en) for English

var Clock = "12h"; // 12h or 24h

var gps = false;  // "true or false"; requires MyLocation app or another GPS widget set to "false" to use the code

var locale = "ITXX0042"; // put ZipCode,if you not want to use the GPS set GPS to false and respring!

var tempUnit = "c"; // f for fahrenheit

var IconSet = "StyleiOS7"; // if don't have others,don't touch!!

var iconExt = ".png"  // icons extension

var updateInterval = 4;  // in minutes


var useRealFeel = false; // true or false
