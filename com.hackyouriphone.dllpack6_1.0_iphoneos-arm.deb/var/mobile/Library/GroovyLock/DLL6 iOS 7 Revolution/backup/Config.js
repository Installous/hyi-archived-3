var lang = "en"; // (fr) for French, (de) for German, (es) for Spanish, (it) for Italian, (en) for English

var Clock = "12h"; // 12h or 24h

var yourtext = "Enjoy Your iPhone"; // add your own text

var gps = false;  // "true or false" requires MyLocation app or another GPS widget set to "false" to use the code

var locale = "ITXX0042"; // put here your ZipCode,if you not want to use the GPS set GPS to false and respring,if have any problem contact me

var tempUnit = "c"; // "c" for Celsius, "f" for Fahrenheit

var IconSet = "StyleiOS7"; // if don't have others,don't touch!!

var iconExt = ".png"  // icons extension

var updateInterval = 5;  // in minutes


var useRealFeel = false; // true or false
