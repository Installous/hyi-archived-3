var Lang = "en"; // (fr) for French, (de) for German, (es) for Spanish, (it) for Italian, (en) for English
var Clock = "12"; // 12 or 24
var locale = "itxx0042"; // Here your weather code,if have problem contact me
var Temp = "c"; // c for Celsius, f for Fahrenheit
var updateInterval = 5; // choose the minutes for refresh automatically
var iconSet = "FlatYahoo"; // if don't have others no touch here!
var iconExt = ".png"; // icon extension
var useRealFeel = false; // true or false
