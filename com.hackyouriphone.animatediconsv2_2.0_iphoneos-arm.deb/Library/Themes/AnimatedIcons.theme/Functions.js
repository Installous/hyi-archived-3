// document.write("<style>img{" + "height:" + IconSize*0.57 + "px" + ";" + "width:" + IconSize*0.57 + "px" + ";" + "padding-top:" + (100-IconSize)*0.5 + "%;}</style>");

function layoutIcons(){
			
	if (layout == "Config") {
		document.getElementById("configMessage").style.cssText = "margin:10px;margin-top: 100px;width:300px; height:460px; text-align: center;font-size: 13px;font-family: sans-serif; color:#FFF; text-shadow: #000 0px 2px 2px;";
		document.getElementById("container").style.cssText = "display:none;";
	}

// LAYOUT
		
	if (layout == "5x5") {
		// ROW 1
		document.getElementById("div11").style.top = "2px";
		document.getElementById("div11").style.left = "5px";
		document.getElementById("div12").style.top = "2px";
		document.getElementById("div12").style.left = "68px";
		document.getElementById("div13").style.top = "2px";		
		document.getElementById("div13").style.left = "131px";	
		document.getElementById("div14").style.top = "2px";
		document.getElementById("div14").style.left = "194px";		
		document.getElementById("div15").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:2px;left:257px;";
		// ROW 2
		document.getElementById("div21").style.top = "75px";
		document.getElementById("div21").style.left = "5px";
		document.getElementById("div22").style.top = "75px";
		document.getElementById("div22").style.left = "68px";
		document.getElementById("div23").style.top = "75px";		
		document.getElementById("div23").style.left = "131px";	
		document.getElementById("div24").style.top = "75px";
		document.getElementById("div24").style.left = "194px";		
		document.getElementById("div25").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:75px;left:257px;";
		// ROW 3
		document.getElementById("div31").style.top = "147px";
		document.getElementById("div31").style.left = "5px";
		document.getElementById("div32").style.top = "147px";
		document.getElementById("div32").style.left = "68px";
		document.getElementById("div33").style.top = "147px";		
		document.getElementById("div33").style.left = "131px";	
		document.getElementById("div34").style.top = "147px";
		document.getElementById("div34").style.left = "194px";		
		document.getElementById("div35").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:147px;left:257px;";
		// ROW 4
		document.getElementById("div41").style.top = "220px";
		document.getElementById("div41").style.left = "5px";
		document.getElementById("div42").style.top = "220px";
		document.getElementById("div42").style.left = "68px";
		document.getElementById("div43").style.top = "220px";		
		document.getElementById("div43").style.left = "131px";	
		document.getElementById("div44").style.top = "220px";
		document.getElementById("div44").style.left = "194px";		
		document.getElementById("div45").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:220px;left:257px;";
		// ROW 5
		document.getElementById("div51").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:293px;left:5px;";
		document.getElementById("div52").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:293px;left:68px;";
		document.getElementById("div53").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:293px;left:131px;";
		document.getElementById("div54").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:293px;left:194px;";
		document.getElementById("div55").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:293px;left:257px;";		
	}
	
	if(layout=="5x4"){
		// ROW 1
		document.getElementById("div11").style.left = "5px";
		document.getElementById("div12").style.left = "68px";	
		document.getElementById("div13").style.left = "131px";	
		document.getElementById("div14").style.left = "194px";		
		document.getElementById("div15").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:14px;left:257px;";
		// ROW 2
		document.getElementById("div21").style.left = "5px";
		document.getElementById("div22").style.left = "68px";		
		document.getElementById("div23").style.left = "131px";	
		document.getElementById("div24").style.left = "194px";		
		document.getElementById("div25").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:102px;left:257px;";
		// ROW 3
		document.getElementById("div31").style.left = "5px";
		document.getElementById("div32").style.left = "68px";		
		document.getElementById("div33").style.left = "131px";	
		document.getElementById("div34").style.left = "194px";		
		document.getElementById("div35").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:190px;left:257px;";
		// ROW 4
		document.getElementById("div41").style.left = "5px";
		document.getElementById("div42").style.left = "68px";		
		document.getElementById("div43").style.left = "131px";	
		document.getElementById("div44").style.left = "194px";		
		document.getElementById("div45").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:278px;left:257px;";	
	}
	
	if(layout=="4x5"){
		// ROW 1
		document.getElementById("div11").style.top = "2px";
		document.getElementById("div12").style.top = "2px";
		document.getElementById("div13").style.top = "2px";	
		document.getElementById("div14").style.top = "2px";	
		// ROW 2
		document.getElementById("div21").style.top = "75px";
		document.getElementById("div22").style.top = "75px";
		document.getElementById("div23").style.top = "75px";		
		document.getElementById("div24").style.top = "75px";		
		// ROW 3
		document.getElementById("div31").style.top = "147px";
		document.getElementById("div32").style.top = "147px";
		document.getElementById("div33").style.top = "147px";		
		document.getElementById("div34").style.top = "147px";	
		// ROW 4
		document.getElementById("div41").style.top = "220px";
		document.getElementById("div42").style.top = "220px";
		document.getElementById("div43").style.top = "220px";			
		document.getElementById("div44").style.top = "220px";	
		// ROW 5
		document.getElementById("div51").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:293px;left:17px;";
		document.getElementById("div52").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:293px;left:93px;";
		document.getElementById("div53").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:293px;left:170px;";
		document.getElementById("div54").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:293px;left:246px;";	
	}
		
	if(layout=="3x3Dense"){
		// ROW 1
		document.getElementById("div11").style.top = "85px";
		document.getElementById("div11").style.left = "68px";
		document.getElementById("div12").style.top = "85px";
		document.getElementById("div12").style.left = "131px";
		document.getElementById("div13").style.top = "85px";
		document.getElementById("div13").style.left = "194px";
		document.getElementById("div14").style.cssText = "display:none;";
		// ROW 2
		document.getElementById("div21").style.top = "148px";
		document.getElementById("div21").style.left = "68px";
		document.getElementById("div22").style.top = "148px";
		document.getElementById("div22").style.left = "131px";
		document.getElementById("div23").style.top = "148px";
		document.getElementById("div23").style.left = "194px";
		document.getElementById("div24").style.cssText = "display:none;";
		// ROW 3
		document.getElementById("div31").style.top = "210px";
		document.getElementById("div31").style.left = "68px";
		document.getElementById("div32").style.top = "210px";
		document.getElementById("div32").style.left = "131px";
		document.getElementById("div33").style.top = "210px";
		document.getElementById("div33").style.left = "194px";
		document.getElementById("div34").style.cssText = "display:none;";

		document.getElementById("div41").style.cssText = "display:none;";
		document.getElementById("div42").style.cssText = "display:none;";
		document.getElementById("div43").style.cssText = "display:none;";		
		document.getElementById("div44").style.cssText = "display:none;";
	}
	
	if(layout=="3x3Sparse"){
		// ROW 1
		document.getElementById("div11").style.top = "57px";
		document.getElementById("div11").style.left = "68px";
		document.getElementById("div12").style.top = "57px";
		document.getElementById("div12").style.left = "131px";
		document.getElementById("div13").style.top = "57px";
		document.getElementById("div13").style.left = "194px";
		document.getElementById("div14").style.cssText = "display:none;";
		// ROW 2
		document.getElementById("div21").style.top = "147px";
		document.getElementById("div21").style.left = "68px";
		document.getElementById("div22").style.top = "147px";
		document.getElementById("div22").style.left = "131px";
		document.getElementById("div23").style.top = "147px";
		document.getElementById("div23").style.left = "194px";
		document.getElementById("div24").style.cssText = "display:none;";
		// ROW 3
		document.getElementById("div31").style.top = "235px";
		document.getElementById("div31").style.left = "68px";
		document.getElementById("div32").style.top = "235px";
		document.getElementById("div32").style.left = "131px";
		document.getElementById("div33").style.top = "235px";
		document.getElementById("div33").style.left = "194px";
		document.getElementById("div34").style.cssText = "display:none;";

		document.getElementById("div41").style.cssText = "display:none;";
		document.getElementById("div42").style.cssText = "display:none;";
		document.getElementById("div43").style.cssText = "display:none;";		
		document.getElementById("div44").style.cssText = "display:none;";
	}
	
	if (layout=="5x2Dense"){
			// ROW 1
		document.getElementById("div11").style.top = "115px";
		document.getElementById("div11").style.left = "5px";
		document.getElementById("div12").style.top = "115px";
		document.getElementById("div12").style.left = "68px";
		document.getElementById("div13").style.top = "115px";		
		document.getElementById("div13").style.left = "131px";	
		document.getElementById("div14").style.top = "115px";
		document.getElementById("div14").style.left = "194px";		
		document.getElementById("div15").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:115px;left:257px;";
		// ROW 2
		document.getElementById("div21").style.top = "175px";
		document.getElementById("div21").style.left = "5px";
		document.getElementById("div22").style.top = "175px";
		document.getElementById("div22").style.left = "68px";
		document.getElementById("div23").style.top = "175px";		
		document.getElementById("div23").style.left = "131px";	
		document.getElementById("div24").style.top = "175px";
		document.getElementById("div24").style.left = "194px";		
		document.getElementById("div25").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:175px;left:257px;";	
		
		document.getElementById("div31").style.cssText = "display:none;";
		document.getElementById("div32").style.cssText = "display:none;";
		document.getElementById("div33").style.cssText = "display:none;";		
		document.getElementById("div34").style.cssText = "display:none;";
		
		document.getElementById("div41").style.cssText = "display:none;";
		document.getElementById("div42").style.cssText = "display:none;";
		document.getElementById("div43").style.cssText = "display:none;";		
		document.getElementById("div44").style.cssText = "display:none;";		
	}
		
	if (layout=="5x2Sparse"){
		// ROW 1
		document.getElementById("div11").style.top = "101px";
		document.getElementById("div11").style.left = "5px";
		document.getElementById("div12").style.top = "101px";
		document.getElementById("div12").style.left = "68px";
		document.getElementById("div13").style.top = "101px";		
		document.getElementById("div13").style.left = "131px";	
		document.getElementById("div14").style.top = "101px";
		document.getElementById("div14").style.left = "194px";		
		document.getElementById("div15").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:101px;left:257px;";
		// ROW 2
		document.getElementById("div21").style.top = "190px";
		document.getElementById("div21").style.left = "5px";
		document.getElementById("div22").style.top = "190px";
		document.getElementById("div22").style.left = "68px";
		document.getElementById("div23").style.top = "190px";		
		document.getElementById("div23").style.left = "131px";	
		document.getElementById("div24").style.top = "190px";
		document.getElementById("div24").style.left = "194px";		
		document.getElementById("div25").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:190px;left:257px;";	
		
		document.getElementById("div31").style.cssText = "display:none;";
		document.getElementById("div32").style.cssText = "display:none;";
		document.getElementById("div33").style.cssText = "display:none;";		
		document.getElementById("div34").style.cssText = "display:none;";
		
		document.getElementById("div41").style.cssText = "display:none;";
		document.getElementById("div42").style.cssText = "display:none;";
		document.getElementById("div43").style.cssText = "display:none;";		
		document.getElementById("div44").style.cssText = "display:none;";		
	}
	
}

function pageOneIcons(){

//ROW 1 ICONS	
	document.getElementById("row1col1").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R1C1+".gif";
	document.getElementById("row1col2").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R1C2+".gif";
	document.getElementById("row1col3").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R1C3+".gif";
	document.getElementById("row1col4").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R1C4+".gif";
	document.getElementById("row1col5").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R1C5+".gif";
// ROW 2 ICONS
	document.getElementById("row2col1").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R2C1+".gif";
	document.getElementById("row2col2").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R2C2+".gif";
	document.getElementById("row2col3").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R2C3+".gif";
	document.getElementById("row2col4").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R2C4+".gif";
	document.getElementById("row2col5").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R2C5+".gif";	
// ROW 3 ICONS
	document.getElementById("row3col1").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R3C1+".gif";
	document.getElementById("row3col2").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R3C2+".gif";
	document.getElementById("row3col3").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R3C3+".gif";
	document.getElementById("row3col4").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R3C4+".gif";
	document.getElementById("row3col5").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R3C5+".gif";
// ROW 4 ICONS
	document.getElementById("row4col1").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R4C1+".gif";
	document.getElementById("row4col2").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R4C2+".gif";
	document.getElementById("row4col3").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R4C3+".gif";
	document.getElementById("row4col4").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R4C4+".gif";
	document.getElementById("row4col5").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R4C5+".gif";
// ROW 5 ICONS
	document.getElementById("row5col1").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R5C1+".gif";
	document.getElementById("row5col2").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R5C2+".gif";
	document.getElementById("row5col3").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R5C3+".gif";
	document.getElementById("row5col4").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R5C4+".gif";
	document.getElementById("row5col5").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P1R5C5+".gif";

// NIL ICONS
	if (P1R1C1 == "Nil"){document.getElementById("div11").style.cssText = "display:none;";}
	if (P1R1C2 == "Nil"){document.getElementById("div12").style.cssText = "display:none;";}
	if (P1R1C3 == "Nil"){document.getElementById("div13").style.cssText = "display:none;";}
	if (P1R1C4 == "Nil"){document.getElementById("div14").style.cssText = "display:none;";}
	if (P1R1C5 == "Nil"){document.getElementById("div15").style.cssText = "display:none;";}
	
	if (P1R2C1 == "Nil"){document.getElementById("div21").style.cssText= "display:none;";}
	if (P1R2C2 == "Nil"){document.getElementById("div22").style.cssText= "display:none;";}
	if (P1R2C3 == "Nil"){document.getElementById("div23").style.cssText= "display:none;";}
	if (P1R2C4 == "Nil"){document.getElementById("div24").style.cssText= "display:none;";}
	if (P1R2C5 == "Nil"){document.getElementById("div25").style.cssText= "display:none;";}
	
	if (P1R3C1 == "Nil"){document.getElementById("div31").style.cssText= "display:none;";}
	if (P1R3C2 == "Nil"){document.getElementById("div32").style.cssText= "display:none;";}
	if (P1R3C3 == "Nil"){document.getElementById("div33").style.cssText= "display:none;";}
	if (P1R3C4 == "Nil"){document.getElementById("div34").style.cssText= "display:none;";}
	if (P1R3C5 == "Nil"){document.getElementById("div35").style.cssText= "display:none;";}
	
	if (P1R4C1 == "Nil"){document.getElementById("div41").style.cssText= "display:none;";}
	if (P1R4C2 == "Nil"){document.getElementById("div42").style.cssText= "display:none;";}
	if (P1R4C3 == "Nil"){document.getElementById("div43").style.cssText= "display:none;";}
	if (P1R4C4 == "Nil"){document.getElementById("div44").style.cssText= "display:none;";}
	if (P1R4C5 == "Nil"){document.getElementById("div45").style.cssText= "display:none;";}
	
	if (P1R5C1 == "Nil"){document.getElementById("div51").style.cssText= "display:none;";}
	if (P1R5C2 == "Nil"){document.getElementById("div52").style.cssText= "display:none;";}
	if (P1R5C3 == "Nil"){document.getElementById("div53").style.cssText= "display:none;";}
	if (P1R5C4 == "Nil"){document.getElementById("div54").style.cssText= "display:none;";}
	if (P1R5C5 == "Nil"){document.getElementById("div55").style.cssText= "display:none;";}
	
}

function pageTwoIcons(){

//ROW 1 ICONS	
	document.getElementById("row1col1").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R1C1+".gif";
	document.getElementById("row1col2").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R1C2+".gif";
	document.getElementById("row1col3").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R1C3+".gif";
	document.getElementById("row1col4").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R1C4+".gif";
	document.getElementById("row1col5").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R1C5+".gif";
// ROW 2 ICONS
	document.getElementById("row2col1").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R2C1+".gif";
	document.getElementById("row2col2").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R2C2+".gif";
	document.getElementById("row2col3").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R2C3+".gif";
	document.getElementById("row2col4").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R2C4+".gif";
	document.getElementById("row2col5").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R2C5+".gif";	
// ROW 3 ICONS
	document.getElementById("row3col1").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R3C1+".gif";
	document.getElementById("row3col2").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R3C2+".gif";
	document.getElementById("row3col3").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R3C3+".gif";
	document.getElementById("row3col4").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R3C4+".gif";
	document.getElementById("row3col5").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R3C5+".gif";
// ROW 4 ICONS
	document.getElementById("row4col1").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R4C1+".gif";
	document.getElementById("row4col2").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R4C2+".gif";
	document.getElementById("row4col3").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R4C3+".gif";
	document.getElementById("row4col4").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R4C4+".gif";
	document.getElementById("row4col5").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R4C5+".gif";
// ROW 5 ICONS
	document.getElementById("row5col1").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R5C1+".gif";
	document.getElementById("row5col2").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R5C2+".gif";
	document.getElementById("row5col3").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R5C3+".gif";
	document.getElementById("row5col4").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R5C4+".gif";
	document.getElementById("row5col5").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  P2R5C5+".gif";

// NIL ICONS
	if (P2R1C1 == "Nil"){document.getElementById("div11").style.cssText = "display:none;";}
	if (P2R1C2 == "Nil"){document.getElementById("div12").style.cssText = "display:none;";}
	if (P2R1C3 == "Nil"){document.getElementById("div13").style.cssText = "display:none;";}
	if (P2R1C4 == "Nil"){document.getElementById("div14").style.cssText = "display:none;";}
	if (P2R1C5 == "Nil"){document.getElementById("div15").style.cssText = "display:none;";}
	
	if (P2R2C1 == "Nil"){document.getElementById("div21").style.cssText= "display:none;";}
	if (P2R2C2 == "Nil"){document.getElementById("div22").style.cssText= "display:none;";}
	if (P2R2C3 == "Nil"){document.getElementById("div23").style.cssText= "display:none;";}
	if (P2R2C4 == "Nil"){document.getElementById("div24").style.cssText= "display:none;";}
	if (P2R2C5 == "Nil"){document.getElementById("div25").style.cssText= "display:none;";}
	
	if (P2R3C1 == "Nil"){document.getElementById("div31").style.cssText= "display:none;";}
	if (P2R3C2 == "Nil"){document.getElementById("div32").style.cssText= "display:none;";}
	if (P2R3C3 == "Nil"){document.getElementById("div33").style.cssText= "display:none;";}
	if (P2R3C4 == "Nil"){document.getElementById("div34").style.cssText= "display:none;";}
	if (P2R3C5 == "Nil"){document.getElementById("div35").style.cssText= "display:none;";}
	
	if (P2R4C1 == "Nil"){document.getElementById("div41").style.cssText= "display:none;";}
	if (P2R4C2 == "Nil"){document.getElementById("div42").style.cssText= "display:none;";}
	if (P2R4C3 == "Nil"){document.getElementById("div43").style.cssText= "display:none;";}
	if (P2R4C4 == "Nil"){document.getElementById("div44").style.cssText= "display:none;";}
	if (P2R4C5 == "Nil"){document.getElementById("div45").style.cssText= "display:none;";}
	
	if (P2R5C1 == "Nil"){document.getElementById("div51").style.cssText= "display:none;";}
	if (P2R5C2 == "Nil"){document.getElementById("div52").style.cssText= "display:none;";}
	if (P2R5C3 == "Nil"){document.getElementById("div53").style.cssText= "display:none;";}
	if (P2R5C4 == "Nil"){document.getElementById("div54").style.cssText= "display:none;";}
	if (P2R5C5 == "Nil"){document.getElementById("div55").style.cssText= "display:none;";}
	
}
	
function Wallpaper(){

// LAYOUT

if (noOfDockIcons == 1){
	document.getElementById("div1").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:402px;left:131px;";
	document.getElementById("div2").style.cssText = "display:none;";
	document.getElementById("div3").style.cssText = "display:none;";
	document.getElementById("div4").style.cssText = "display:none;";
	document.getElementById("div5").style.cssText = "display:none;";
}
if (noOfDockIcons == 2){
	document.getElementById("div1").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:402px;left:93px;";
	document.getElementById("div2").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:402px;left:169px;";
	document.getElementById("div3").style.cssText = "display:none;";
	document.getElementById("div4").style.cssText = "display:none;";
	document.getElementById("div5").style.cssText = "display:none;";
}
if (noOfDockIcons == 3){
	document.getElementById("div1").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:402px;left:55px;";
	document.getElementById("div2").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:402px;left:131px;";
	document.getElementById("div3").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:402px;left:208px;";
	document.getElementById("div4").style.cssText = "display:none;";
	document.getElementById("div5").style.cssText = "display:none;";
}
if (noOfDockIcons == 5){
	document.getElementById("div1").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:402px;left:5px;";
	document.getElementById("div2").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:402px;left:68px;";
	document.getElementById("div3").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:402px;left:131px;";
	document.getElementById("div4").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:402px;left:194px;";
	document.getElementById("div5").style.cssText = "height:57px;width:57px;text-align:center;position:absolute;top:402px;left:257px;";
}

// ICONS

	document.getElementById("dock1").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  D1+".gif";
	document.getElementById("dock2").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  D2+".gif";
	document.getElementById("dock3").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  D3+".gif";
	document.getElementById("dock4").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  D4+".gif";
	document.getElementById("dock5").src = "/Library/Themes/AnimatedIcons.theme/Icons/" + quality + "/" +  D5+".gif";


	if (D1 == "Nil"){document.getElementById("div1").style.cssText = "display:none;";}
	if (D2 == "Nil"){document.getElementById("div2").style.cssText = "display:none;";}
	if (D3 == "Nil"){document.getElementById("div3").style.cssText = "display:none;";}
	if (D4 == "Nil"){document.getElementById("div4").style.cssText = "display:none;";}
	if (D5 == "Nil"){document.getElementById("div5").style.cssText = "display:none;";}
	
	if (layout == "Config"){
		document.getElementById("div1").style.cssText = "display:none;";
		document.getElementById("div2").style.cssText = "display:none;";
		document.getElementById("div3").style.cssText = "display:none;";
		document.getElementById("div4").style.cssText = "display:none;";
		document.getElementById("div5").style.cssText = "display:none;";
	}
}