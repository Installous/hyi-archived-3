//  !!!  IMPORTANT !!!  iOS is CASE SENSITIVE - cydia.gif is NOT the same as Cydia.gif

var quality = "HD" // HD or SD

var noOfDockIcons = 4 // 1, 2, 3, 4 or 5

var layout = "Config" 	// For Iconoclasm
// Available layouts: '3x3Dense', '3x3Sparse', '4x4', '5x4', '4x5', '5x5', '5x2Dense', '5x2Sparse'
// Also note: 4x5 = 'FivelRows Improved', 5x5 = '5x5 NOT from 1.0'

// ICONS

// P1R1C1 means Page 1 Row 1 Column 1, P1R1C2 = Page 1 Row 1 Column 2 etc.

// AVAILABLE ICONS (EXACTLY as they appear)
//		AppStore
//		Calculator
//		Calendar
//		Camera
//		Clock
//		Compass
//		Contacts
//		Cydia
//		Facebook
//    		FaceTime
//		Folder
//		GameCenter
//		iMessage
//		Installous
//		iTunes
//		Mail
//		Maps
//		Music
//		Notes
//		Phone
//		Photos
//		Reminders
//		Safari
//		Settings
//		SMS
//		Stocks
//		Twitter
//		Videos
//		VoiceMemos
//		Weather
//		WinterBoard
//		YouTube
//     FaceTime
// IF YOU DO NOT WANT AN ICON IN THE POSITION TYPE "Nil"


// DOCK
var D1 = "Nil" 
var D2 = "Nil"
var D3 = "Nil"
var D4 = "Nil"
var D5 = "Nil"



// PAGE 1

// ROW 1
var P1R1C1 = "Nil" 
var P1R1C2 = "Nil"
var P1R1C3 = "Nil"
var P1R1C4 = "Nil"
var P1R1C5 = "Nil"

// ROW 2
var P1R2C1 = "Nil" 
var P1R2C2 = "Nil"
var P1R2C3 = "Nil"
var P1R2C4 = "Nil"
var P1R2C5 = "Nil"

// ROW 3
var P1R3C1 = "Nil" 
var P1R3C2 = "Nil"
var P1R3C3 = "Nil"
var P1R3C4 = "Nil"
var P1R3C5 = "Nil"

// ROW 4
var P1R4C1 = "Nil" 
var P1R4C2 = "Nil"
var P1R4C3 = "Nil"
var P1R4C4 = "Nil"
var P1R4C5 = "Nil" 

// ROW 5
var P1R5C1 = "Nil" 
var P1R5C2 = "Nil"
var P1R5C3 = "Nil"
var P1R5C4 = "Nil"
var P1R5C5 = "Nil" 



// PAGE 2

// ROW 1
var P2R1C1 = "Nil" 
var P2R1C2 = "Nil"
var P2R1C3 = "Nil"
var P2R1C4 = "Nil"
var P2R1C5 = "Nil"

// ROW 2
var P2R2C1 = "Nil" 
var P2R2C2 = "Nil"
var P2R2C3 = "Nil"
var P2R2C4 = "Nil"
var P2R2C5 = "Nil"

// ROW 3
var P2R3C1 = "Nil" 
var P2R3C2 = "Nil"
var P2R3C3 = "Nil"
var P2R3C4 = "Nil"
var P2R3C5 = "Nil"

// ROW 4
var P2R4C1 = "Nil" 
var P2R4C2 = "Nil"
var P2R4C3 = "Nil"
var P2R4C4 = "Nil"
var P2R4C5 = "Nil" 

// ROW 5
var P2R5C1 = "Nil" 
var P2R5C2 = "Nil"
var P2R5C3 = "Nil"
var P2R5C4 = "Nil"
var P2R5C5 = "Nil" 