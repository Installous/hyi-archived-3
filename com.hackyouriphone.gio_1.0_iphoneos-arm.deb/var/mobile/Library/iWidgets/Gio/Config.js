var Scale = "1"; 
var DarkMode = false; 
var IconWeather = "W"; // choose your weather icon pack herr
