snowboard icon as Icon.png
