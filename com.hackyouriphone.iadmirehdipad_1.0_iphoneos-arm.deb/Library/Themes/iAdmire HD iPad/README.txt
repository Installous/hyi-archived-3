						iAdmire HD 
						
				Thanks for downloading my theme! I hope you like it and will be happy with my work!
				This is my first "actual" theme and I'm pretty proud :P
				
				Tips:
					1. If you want to keep your "slide to unlock text" simply remove the folder called "Folders"
					2. If you want to change the "slide to unlock" or "iAdmire HD" text simply go into Folders/SpringBoard.app/yourlanguage.lproj/ and edit the SpringBoard.strings with a text editor.
					
							
							
							Copyright 2012 Matheos Mattsson (aka 0rangedev)