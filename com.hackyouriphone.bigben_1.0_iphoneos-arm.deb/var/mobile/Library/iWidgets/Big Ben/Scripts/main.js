window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentMonth = currentTime.getMonth() + 1;
var currentDate1 = currentTime.getDate() - 1;
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

if (Clock == "24h"){
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}
if (Clock == "12h"){
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentHours = ( currentHours == 0 ) ? "12" : currentHours;
	currentHours = ( currentHours == 13 ) ? "01" : currentHours;
	currentHours = ( currentHours == 14 ) ? "02" : currentHours;
	currentHours = ( currentHours == 15 ) ? "03" : currentHours;
	currentHours = ( currentHours == 16 ) ? "04" : currentHours;
	currentHours = ( currentHours == 17 ) ? "05" : currentHours;
	currentHours = ( currentHours == 18 ) ? "06" : currentHours;
	currentHours = ( currentHours == 19 ) ? "07" : currentHours;
	currentHours = ( currentHours == 20 ) ? "08" : currentHours;
	currentHours = ( currentHours == 21 ) ? "09" : currentHours;
	currentHours = ( currentHours == 22 ) ? "10" : currentHours;
	currentHours = ( currentHours == 23 ) ? "11" : currentHours;
	currentHours = ( currentHours == 24 ) ? "12" : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}

document.getElementById("hour").innerHTML = currentHours = ( currentHours < 10 ? "" : "" ) + currentHours;
document.getElementById("minute").innerHTML = currentMinutes;
document.getElementById("ampm").innerHTML = timeOfDay;
document.getElementById("weekday").innerHTML = days[currentTime.getDay()];
document.getElementById("today").innerHTML = today[currentTime.getHours()];
document.getElementById("today1").innerHTML = today1[currentTime.getHours()];
document.getElementById("fecha").innerHTML = currentDate;
document.getElementById("month").innerHTML = shortmonths[currentTime.getMonth()];
document.getElementById("battery").innerHTML = battery;

document.getElementById('hour').style.color = Clock_color;
document.getElementById('minute').style.color = Clock_color;

document.getElementById('ampm').style.color = AM_PM_color;

document.getElementById('weekday').style.color = Calendar_color;
document.getElementById('coma').style.color = Calendar_color;
document.getElementById('fecha').style.color = Calendar_color;
document.getElementById('month').style.color = Calendar_color;
document.getElementById('punto').style.color = Calendar_color;

document.getElementById('today').style.color = Regards_color;
document.getElementById('today1').style.color = Regards_color;

document.getElementById('temp').style.color = Temperature_color;

document.getElementById('desc').style.color = Weather_color;

document.getElementById('battery').style.color = Battery_color;

document.getElementById('LevelDisplay').style.color = BatteryPercentage_color;

}

function init(){
updateClock();
setInterval("updateClock();", 1000);
}