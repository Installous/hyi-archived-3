//NOTICE/// This settings file is now only used for setting the default values of variables and changing advanced settings.   For all other changes, you should use the settings panel in the lockscreen itself////

digital = true;    				// whether to display the digital clock

date = true;       				// whether to display the date

hour24 = true;     				// whether to use 24 hour time

square = true; 	   				// shape of indicator dots; if set to false, indicators will be circular.

color = "#F10000"; 	   				//Text color, or all color if multicolor is set to false (you may replace the numbers with a common colorname if you wish, but DO NOT remove the parenthesis)

cols ={1:"#F10000",2:"#00F100",3:"#2030FF"}; 	//Color by columns; 1 is hours, 2 is minutes, and 3 is seconds(this only works if multicolor is set to true, and again you may replace the numbers with common colornames)
sblur = 20;                     // shadow blur This determines how much things "glow" Default is 20