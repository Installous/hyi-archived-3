
var updateInterval = "15"; //weather refresh in minutes

var ss = "8"; // slideshow interval in seconds

var slideshow = true; //true or false

var dark = true; //true or false for a dark transparent widget background

var ytext = "arthouse"; //your own text

var tempUnit = "f"; // "c" for Celius or "f" for Fahrenheit

var lang = "en"; 
/* choose the widget language here
English - en
German - de
French - fr
Italian -it
Spanish - sp
Danish - da
Turkish - tr
*/

var Clock = "12h"; // "12h" or "24h"

var locale = "689996"; // Your Yahoo location/city code

var gps = "false"; //needs WidgetWeather from Cydia

var UseNeighborhood = "false";

var UseCityGPS = "false";
