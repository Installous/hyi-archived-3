
updateClock();
 setInterval('updateClock()', 60000 );
function updateClock(){
    // var TwentyFourHourClock = localStorage.getItem('time'); 
     var TwentyFourHourClock ="true";
savedTwentyFourHourClock=localStorage.getItem('time');

if(savedTwentyFourHourClock==="true"){
  TwentyFourHourClock="true";
}
else{
  TwentyFourHourClock="false";
}

   
if (TwentyFourHourClock == "true"){
   var currentTime = new Date ( );
   var currentHours = currentTime.getHours ( );
   var currentMinutes = currentTime.getMinutes ( );
   var currentSeconds = currentTime.getSeconds ( );
   currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
   currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
   var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
   currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
   currentHours = ( currentHours == 0 ) ? 12 : currentHours;
   var currentTimeString = currentHours + ":" + currentMinutes;
  document.getElementById("time").innerHTML = '<span>' + currentTimeString + '</span>'
}

if (TwentyFourHourClock == "false"){

   var currentTime = new Date ( );
   var currentHours = currentTime.getHours ( );
   var currentMinutes = currentTime.getMinutes ( );
  var currentSeconds = currentTime.getSeconds ( ); currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;
  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  var currentTimeString = currentHours + ":" + currentMinutes;
  document.getElementById("time").innerHTML = '<span>' + currentTimeString + '</span>'
}

calendarDate();
}
 



 function calendarDate (){

var lang="en";

    get=localStorage.getItem("languages");
if(get!=null){
  lang=get;
}



switch (lang) {
case "fr":
  var this_weekday_name_array = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
  var this_month_name_array=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];
break;
case "de":
  var this_weekday_name_array = ["Son","Mon","Die","Mit","Don","Fre","Sam"];
  var this_month_name_array=["Januar","Februar","Marz","April","Mai","Juni","Juli","August","September ","Oktober","November","Dezember"];     
break;
case "sp":
  var this_weekday_name_array = ["Dom","Lun","Mar","Mie","Jue","Vie","Sab"];
  var this_month_name_array=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Juliot','Agosto','Septiembre','Octubre','Novimbre','Decimbre'];
break;
case "it":
  var this_weekday_name_array = ["Dom","Lun","Mar","Mer","Gio","Ven","Sab"];
  var this_month_name_array=['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];
break;
default: 
  var this_weekday_name_array = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var this_month_name_array=["January","February","March","April","May","June","July","August","September","October","November","December"];
break;
}

   var this_date_timestamp = new Date()
   var this_weekday = this_date_timestamp.getDay()
   var this_date = this_date_timestamp.getDate()
   var this_month = this_date_timestamp.getMonth()

document.getElementById("date").innerHTML = '<span>' + this_weekday_name_array[this_weekday] + ", " + this_date + " " + this_month_name_array[this_month]+'</span>'


 }



