

App Icon Mask was borrowed from the Soft Remix Theme by �MagWhiz�

http://www.reddit.com/u/MagWhiz
Made by Eduardo L�pez (username MagWhiz)