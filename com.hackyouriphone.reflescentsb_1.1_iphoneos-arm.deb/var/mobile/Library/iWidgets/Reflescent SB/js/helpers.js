/* Helper Functions */
'use strict';

/* reading from Options.plist */
(function () {
    try{
    showSVG('.svgimg', true);
}catch(err){
    alert(err);
}
}());
