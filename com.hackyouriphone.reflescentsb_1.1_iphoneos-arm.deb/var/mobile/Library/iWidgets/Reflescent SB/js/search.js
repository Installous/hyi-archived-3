
function enterKey(key){
  var val;
  window.event?val = window.event.keyCode:key && (val=key.which);
  13 == val && openLink();
}

function closeSearch(){
  document.getElementById("searchBar").className = "hidePixel";
  document.getElementById("pixelSection").className = "showPixel";
  document.getElementById("search").blur();
}

function openSearch(){
  document.getElementById("pixelSection").className = "hidePixel";
  setTimeout( function() {
    document.getElementById("searchBar").className = "showPixel";
  }, 500 );
  document.getElementById("search").focus();
}

function openLink(){
  closeSearch();
  var search = document.getElementById("search");
  var word = search.value;
  word = encodeURIComponent(word);
  var link = document.getElementById("safari");
  link.href = "http://www.google.com/search?q=" + word;
  setTimeout(function(){
    search.value = "";
  },5000);
  link.click();
}
