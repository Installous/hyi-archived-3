var TextColor = "Black";
var BackgroundColor = "linear-gradient(to top, #ff0099, #493240)";
var DarkIcons = true;
var ZoomLevel = 70;
