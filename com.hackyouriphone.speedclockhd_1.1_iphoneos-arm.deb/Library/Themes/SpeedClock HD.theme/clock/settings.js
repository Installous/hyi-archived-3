backgroundcolr= "#000000";		// sets the color of the background(you may replace the numbers with a common colorname if you wish, but DO NOT remove the parenthesis)

textcolor = "#EA0000";			// sets the color of the date(you may replace the numbers with a common colorname if you wish, but DO NOT remove the parenthesis)

digitcolor= "#EA0000";			// sets the color of the digital clock(you may replace the numbers with a common colorname if you wish, but DO NOT remove the parenthesis)

ringcolor = "#EA0000";          // sets the color for the rotating arrows and stationary rings if multicolor is set to "false"

sblur = 20; 	//	//	//	//	// sets the amount of blur for shadow effects(default is 20)

mil = true; 	//	//	//	//	// 24 hour or "military" time.  Set this to "false" if you prefer 12 hour time.

inner = false;	//	//	//	//	// whether the inner ring is displayed

outer = false;	//	//	//	//	// whether the outer ring is displayed

multicolor=true;                // whether the ringcolor should be the color for all of the arrows

secondcolor="#EA0000";			// the color which the innermost seconds arrow will be if multicolor is set to "true"(you may replace the numbers with a common colorname if you wish, but DO NOT remove the parenthesis)
minutecolor="#00EA00";			// the color which the middle minutes arrow will be if multicolor is set to "true"(you may replace the numbers with a common colorname if you wish, but DO NOT remove the parenthesis)
hourcolor="#0000EA";			// the color which the outermost hours arrow will be if multicolor is set to "true"(you may replace the numbers with a common colorname if you wish, but DO NOT remove the parenthesis)