
var acc_x, acc_y;
var deg = 0;
var deg_new = 0;
var deg_set = 0;
var deg_time = 0;
var state = 'default';

function update() {	
	document.getElementById("bka2hung").style.webkitTransform = 'rotate(' + rotate() + 'deg)';
	setTimeout(update, 1000);
}	

function rotate (accelerationx, accelerationy) {
	deg_time++;

	if (acc_y < 3 && acc_x > -7 && acc_x < 7) {
		//normal
		deg_new = 0;
		state = 'normal';
	} else if (acc_x < -6) {
		//left
		deg_new = 90;
		state = 'left';
	} else if (acc_x > 6) {
		//right
		deg_new = -90;
		state = 'right';
	} else if (acc_y > 4) {
		//upside
		deg_new = -180;
		state = 'upside';
	}
	
	if (deg != deg_new) {
		difference = deg_time - deg_set;
		
		if (difference >= 2 || deg_set == 0) {
			deg_set = deg_time;
			deg = deg_new;
		} else {
			//animation postponed
		}
	}
	
	//if decision wasnt made, default or previous deg value will be returned
	//console.log(acc_y + ' ' + acc_x + ' ' + state); // used for debugging 
 	return deg;
}



if (window.DeviceMotionEvent) {
	window.addEventListener('devicemotion', deviceMotionHandler, false);
}

function deviceMotionHandler(eventData) {
	var acceleration = eventData.accelerationIncludingGravity;

	acc_x = acceleration.x;
	acc_y = acceleration.y;
}
