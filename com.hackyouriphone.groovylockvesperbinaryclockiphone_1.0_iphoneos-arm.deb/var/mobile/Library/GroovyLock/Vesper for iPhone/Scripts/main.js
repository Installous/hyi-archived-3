var xmldata = false;
var postal;
var refreshLocationTimer;
var updateTimer = 0;
var zip;

switch (lang) {
case "fr":
	var days = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
	var months=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];
break;

case "de":
	var days = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
	var months=["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];		
break;

case "da":
	var days = ["S&Oslash;ndag","Mandag","Tirsdag","Onsdag","Torsdag","Fredag","L&Oslash;rdag"];
	var months=["Januar","Februar","Marts","April","Maj","Juni","Juli","August","September","Oktober","November","December"];		
break;

case "sp":
	var days = ["Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"];
	var months=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
break;

case "it":
	var days = ["Domenica","Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato"];
	var months=['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];
break;

case "tr":
	var days = ["Pazar","Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi"];
	var months=['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
break;

default: 
	var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	var months=["January","February","March","April","May","June","July","August","September","October","November","December"];
break;}

function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var year = currentTime.getFullYear();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate();
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";
if (Clock == "24h") {
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
    document.getElementById("hour").innerHTML = currentHours;
    document.getElementById("minute").innerHTML = currentMinutes;
    document.getElementById("ampm").innerHTML = timeOfDay;}
if (Clock == "12h") {
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentHours = ( currentHours < 10 ? "":"" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
    document.getElementById("hour").innerHTML = currentHours;
    document.getElementById("minute").innerHTML = currentMinutes;
    document.getElementById("ampm").innerHTML = timeOfDay;}
    document.getElementById("year").innerHTML = year;
    document.getElementById("weekday").innerHTML = days[currentTime.getDay()];
    document.getElementById("date").innerHTML = currentDate;
    document.getElementById("month").innerHTML = months[currentTime.getMonth()];
if (currentTime.getTime() - updateTimer >= updateWeatherEvery) {
	if (updateTimer == 0) {
	if (gps == true) { UpdateLocation(); } 
		else { validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal); }} 
		else {weatherRefresherTemp(zip);}
	updateTimer = currentTime.getTime();}}

function init(){
	updateClock();
	setInterval("updateClock();", 1000);}







