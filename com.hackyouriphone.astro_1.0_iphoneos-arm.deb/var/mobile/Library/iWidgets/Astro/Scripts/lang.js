//Translation for major components. Originally by Junesiphone, modified by Evelyn (@ev_ynw) and (@luis9_49)//

if (Lang == "en") {
    var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good", "Good"];
    var today1 = ["Morning", "Morning", "Morning", "Morning", "Morning", "Morning", "Morning", "Morning", "Morning", "Morning", "Morning", "Morning", "Afternoon", "Afternoon", "Afternoon", "Afternoon", "Afternoon", "Afternoon", "Afternoon", "Evening", "Evening", "Evening", "Evening", "Evening", "Evening"];
    var days = 
["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    var shortdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var months=["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var shortmonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var battery = ["Battery"];
    var hourtext = ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];
} 
if (Lang == "cz") {
    var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobré", "Dobrou", "Dobrou", "Dobrou", "Dobrou", "Dobrou", "Dobrou"];
    var today1 = ["ráno", "ráno", "ráno", "ráno", "ráno", "ráno", "ráno", "ráno", "ráno", "ráno", "ráno", "ráno", "odpoledne", "odpoledne", "odpoledne", "odpoledne", "odpoledne", "odpoledne", "odpoledne", "noc", "noc", "noc", "noc", "noc", "noc"];
    var days = ["Neděle", "Pondělí", "Úterý", "Středa", "Čtvrtek", "Pátek", "Sobota"];
    var months = ["Leden", "Únor", "Březen", "Duben", "Květen", "Červen", "Červenec", "Srpen", "Září", "Říjen", "Listopad", "Prosinec"];
    var shortmonths = ["Led", "Úno", "Bře", "Dub", "Kvě", "Čen", "Čec", "Srp", "Zář", "Říj", "Lis", "Pro"];
    var shortdays = ["Ne", "Po", "Út", "St", "Čt", "Pá", "So"];
    var battery = ["Baterie"];
} 
if (Lang == "it") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buon", "buon", "buon", "buon", "buon", "buon", "buon", "buona", "buona", "buona", "buona", "buona", "buona"];
    var today1 = ["", "", "", "", "", "", "", "", "", "", "", "", "pomeriggio", "pomeriggio", "pomeriggio", "pomeriggio", "pomeriggio", "pomeriggio", "pomeriggio", "notte", "notte", "notte", "notte", "notte", "notte"];
    var days = ["Domenica", "Lunedi", "Martedì", "Mercoledì", "Giovedi", "Venerdì", "Sabato"];
    var months = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];
    var shortmonths = ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"];
    var shortdays = ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
    var battery = ["Batteria"];
}
if (Lang == "es") {
    var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var days = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
    var months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    var shortmonths = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
    var shortdays = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
    var battery = ["Batería"];
    var hourtext = ["doce", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce"];
    var today = ["Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas"];
    var today1 = ["Días", "Días", "Días", "Días", "Días", "Días", "Días", "Días", "Días", "Días", "Días", "Días", "Tardes", "Tardes", "Tardes", "Tardes", "Tardes", "Tardes", "Tardes", "Noches", "Noches", "Noches", "Noches", "Noches", "Noches"];
}
if (Lang == "de") {
    var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten"];
    var today1 = ["morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "nachmittag", "nachmittag", "nachmittag", "nachmittag", "nachmittag", "nachmittag", "nachmittag", "nacht", "nacht", "nacht", "nacht", "nacht", "nacht"];
    var days = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
    var months = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
    var shortmonths = ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
    var shortdays = ["Son", "Mon", "Die", "Mit", "Don", "Fre", "Sam"];
    var battery = ["Batterie"];
    var hourtext = ["null", "ein", "zwei", "drei", "vier", "f¸nf", "sechs", "sieben", "acht", "neun", "zehn", "elf", "zwˆlf", "dreizehn", "vierzehn", "f¸nfzehn", "sechzehn", "siebzehn", "achtzehn", "neunzehn", "zwanzig", "einundzwanzig", "zweiundzwanzig", "dreiundzwanzig", "null"];
}
if (Lang == "fr") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonne", "Bonne", "Bonne", "Bonne", "Bonne", "Bonne", "Bonne", "Bonsoir", "Bonsoir", "Bonsoir", "Bonsoir", "Bonsoir", "Bonsoir"];
    var today1 = ["", "", "", "", "", "", "", "", "", "", "", "", "après-midi", "après-midi", "après-midi", "après-midi", "après-midi", "après-midi", "après-midi", "", "", "", "", "", ""];
    var days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
    var months = ["Janvie", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
    var shortmonths = ["Jan", "Fév", "Mar", "Avr", "Mai", "Jui", "Jui", "Aoû", "Sep", "Oct", "Nov", "Déc"];
    var shortdays = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
    var battery = ["Batterie"];
    var hourtext = ["minuit", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "midi", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "minuit"];
}
if (Lang == "ru") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["доброе", "доброе", "доброе", "доброе", "доброе", "доброе", "доброе", "доброе", "доброе", "доброе", "доброе", "доброе", "добрый", "добрый", "добрый", "добрый", "добрый", "добрый", "добрый", "спокойной", "спокойной", "спокойной", "спокойной", "спокойной", "спокойной"];
    var today1 = ["утро", "утро", "утро", "утро", "утро", "утро", "утро", "утро", "утро", "утро", "утро", "утро", "день", "день", "день", "день", "день", "день", "день", "ночи", "ночи", "ночи", "ночи", "ночи", "ночи"];
    var days =  ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"];
    var shortdays = ["Вос", "Пон", "Вто", "Сре", "Чет", "Пят", "Суб"];
    var months = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];
    var shortmonths = ["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"];
    var battery = ["побои"];
}
if (Lang == "pl") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dzień", "Dobranoc", "Dobranoc", "Dobranoc", "Dobranoc", "Dobranoc", "Dobranoc"];
    var today1 = ["Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "Dobry", "", "", "", "", "", ""];
    var days = ["Niedziela", "Poniedzialek", "Wtorek", "Sroda", "Czwartek", "Piatek", "Sobota"];
    var shortdays = ["Nie", "Pon", "Wto", "Sro", "Czw", "Pia", "Sob"];
    var months = ["Styczen", "Luty", "Marzec", "Kwiecien", "Maj", "Czerwiec", "Lipiec", "Sierpien", "Wrzesien", "Pazdziernik", "Listopad", "Grudzien"];
    var shortmonths = ["Sty", "Lut", "Mar", "Kwi", "Maj", "Cze", "Lip", "Sie", "Wrz", "Paz", "Lis", "Gru"];
    var battery = ["Bateria"];
}
if (Lang == "pt") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa"];
    var today1 = ["Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "tarde", "tarde", "tarde", "tarde", "tarde", "tarde", "tarde", "noite", "noite", "noite", "noite", "noite", "noite"];
    var days = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sabado"];
    var shortdays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"];
    var months = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    var shortmonths = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
    var battery = ["Pilha"];
}
if (Lang == "no") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God", "God"];
    var today1 = ["morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "ettermiddag", "ettermiddag", "ettermiddag", "ettermiddag", "ettermiddag", "ettermiddag", "ettermiddag", "natt", "natt", "natt", "natt", "natt", "natt"];
    var days = ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"];
    var shortdays = ["Søn", "Man", "Tir", "Ons", "Tor", "Fre", "Lør"];
    var months = ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"];
    var shortmonths = ["Jan", "Feb", "Mar", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Des"];
   var battery = ["Batteri"];
}
if (Lang == "nl") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Goedemorgen", "Goedemorgen", "Goedemorgen", "Goedemorgen", "Goedemorgen", "Goedemorgen", "Goedemorgen", "Goedemorgen", "Goedemorgen", "Goedemorgen", "Goedemorgen", "Goedemorgen", "Goedemiddag", "Goedemiddag", "Goedemiddag", "Goedemiddag", "Goedemiddag", "Goedemiddag", "Goedemiddag", "Goede", "Goede", "Goede", "Goede", "Goede", "Goede"];
    var today1 = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "nacht", "nacht", "nacht", "nacht", "nacht", "nacht"];
    var days = ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"];
    var shortdays = ["Zon", "Maa", "Din", "Woe", "Don", "Vri", "Zat"];
    var months = ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"];
    var shortmonths = ["Jan", "Feb", "Maa", "Apr", "Mei", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"];
    var battery = ["Batterij"];
}
if (Lang == "fi") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää", "Hyvää"];
    var today1 = ["huomenta", "huomenta", "huomenta", "huomenta", "huomenta", "huomenta", "huomenta", "huomenta", "huomenta", "huomenta", "huomenta", "huomenta", "iltapäivää", "iltapäivää", "iltapäivää", "iltapäivää", "iltapäivää", "iltapäivää", "iltapäivää", "yötä", "yötä", "yötä", "yötä", "yötä", "yötä"];
    var days = ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"];
    var shortdays = ["Sun", "Maa", "Tii", "Kes", "Tor", "Per", "Lau"];
    var months = ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kesäkuu", "Heinäkuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"];
    var shortmonths = ["Tam", "Hel", "Maa", "Huh", "Tou", "Kes", "Hei", "Elo", "Syy", "Lok", "Mar", "Jou"];
    var battery = ["Akku"];
}
if (Lang == "cn") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["早安", "早安", "早安", "早安", "早安", "早安", "早安", "早安", "早安", "早安", "早安", "早安", "下午好", "下午好", "下午好", "下午好", "下午好", "下午好", "下午好", "晚安", "晚安", "晚安", "晚安", "晚安", "晚安"];
    var today1 = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
    var days = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
    var shortdays = ["周日","周一","周二","周三","周四","周五","周六"];
    var months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var shortmonths = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var battery = ["电池"];
}
if (Lang == "zh") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["早安", "早安", "早安", "早安", "早安", "早安", "早安", "早安", "早安", "早安", "早安", "早安", "下午好", "下午好", "下午好", "下午好", "下午好", "下午好", "下午好", "晚安", "晚安", "晚安", "晚安", "晚安", "晚安"];
    var today1 = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
    var days = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
    var shortdays = ["週日","週一","週二","週三","週四","週五","週六"];
    var months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var shortmonths = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var battery = ["电池"];
}
if (Lang == "jp") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["おはようございます", "おはようございます", "おはようございます", "おはようございます", "おはようございます", "おはようございます", "おはようございます", "おはようございます", "おはようございます", "おはようございます", "おはようございます", "おはようございます", "こんにちは", "こんにちは", "こんにちは", "こんにちは", "こんにちは", "こんにちは", "こんにちは", "おやすみなさい", "おやすみなさい", "おやすみなさい", "おやすみなさい", "おやすみなさい", "おやすみなさい"];
    var today1 = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
    var days = ["日曜日", "月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日"];
    var shortdays = ["日", "月", "火", "水", "木", "金", "土"];
    var months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var shortmonths = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var battery = ["電池"];
}
if (Lang == "kr") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "좋은", "잘자", "잘자", "잘자", "잘자", "잘자", "잘자"];
    var today1 = ["아침", "아침", "아침", "아침", "아침", "아침", "아침", "아침", "아침", "아침", "아침", "아침", "오후", "오후", "오후", "오후", "오후", "오후", "오후", "", "", "", "", "", ""];
    var days = ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"];
    var shortdays = ["일", "월", "화", "수", "목", "금", "토"];
    var months = ["1등", "2등", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];
    var shortmonths = ["1등", "2등", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];
    var battery = ["배터리"];
}
if (Lang == "tr") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Günaydın", "Günaydın", "Günaydın", "Günaydın", "Günaydın", "Günaydın", "Günaydın", "Günaydın", "Günaydın", "Günaydın", "Günaydın", "Günaydın", "Iyi", "Iyi", "Iyi", "Iyi", "Iyi", "Iyi", "Iyi", "Iyi", "Iyi", "Iyi", "Iyi", "Iyi", "Iyi"];
    var today1 = ["", "", "", "", "", "", "", "", "", "", "", "", "Öğlenler", "Öğlenler", "Öğlenler", "Öğlenler", "Öğlenler", "Öğlenler", "Öğlenler", "geceler", "geceler", "geceler", "geceler", "geceler", "geceler"];
    var days = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"];
    var shortdays = ["Paz", "Paz.", "Sal", "Çar", "Per", "Cum", "Cum."];
    var months = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
    var shortmonths = ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"];
    var battery = ["pil"];
}

