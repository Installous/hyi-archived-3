Having certain Cydia Tweak’s Setting icons unthemed?
Pls follow the steps below, if they are still not themed 
then post your request on the modmyi.com thread :)



Copy and Paste the info.plist in this Extra folder into the following locations:

1. Library/PreferenceLoader/Preferences/

2. Library/PreferenceBundles/CustomFolderIconsSettings.bundle/

If you don't have 2nd tweak, then just do step 1! 


