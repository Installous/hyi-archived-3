#!/bin/bash

killall Camera
killall MobileSlideShow

if [ -e /var/mobile/Media/DCIM_2 ]; then
  mv /var/mobile/Media/DCIM /var/mobile/Media/DCIM_temp
  mv /var/mobile/Media/DCIM_2 /var/mobile/Media/DCIM
  mv /var/mobile/Media/DCIM_temp /var/mobile/Media/DCIM_2
else
  mv /var/mobile/Media/DCIM /var/mobile/Media/DCIM_2
  mkdir /var/mobile/Media/DCIM
  mkdir /var/mobile/Media/DCIM/.MISC
  chown -R mobile:mobile /var/mobile/Media/DCIM
fi
cd /var/mobile/Media/DCIM_2;
for ELEM in * ; do
  if [ -d "$ELEM" ]; then
    if [ ! -d /var/mobile/Media/DCIM/"$ELEM" ]; then
      mkdir /var/mobile/Media/DCIM/"$ELEM"
      chown -R mobile:mobile /var/mobile/Media/DCIM/"$ELEM"
    fi
  fi
done
cp -f /var/mobile/Media/DCIM_2/.MISC/Info.plist /var/mobile/Media/DCIM/.MISC/Info.plist

if [ -e /var/mobile/Media/PhotoData_2 ]; then
  mv /var/mobile/Media/PhotoData /var/mobile/Media/PhotoData_temp
  mv /var/mobile/Media/PhotoData_2 /var/mobile/Media/PhotoData
  mv /var/mobile/Media/PhotoData_temp /var/mobile/Media/PhotoData_2
else
  mv /var/mobile/Media/PhotoData /var/mobile/Media/PhotoData_2
  mkdir /var/mobile/Media/PhotoData
  mkdir /var/mobile/Media/PhotoData/MISC
  chown -R mobile:mobile /var/mobile/Media/PhotoData
fi
cp -f /var/mobile/Media/DCIM/.MISC/Info.plist /var/mobile/Media/PhotoData/MISC/Info.plist

if [ -e /var/mobile/Media/Photos_2 ]; then
	mv /var/mobile/Media/Photos /var/mobile/Media/Photos_temp
	mv /var/mobile/Media/Photos_2 /var/mobile/Media/Photos
	mv /var/mobile/Media/Photos_temp /var/mobile/Media/Photos_2
else
	mv /var/mobile/Media/Photos /var/mobile/Media/Photos_2
	mkdir /var/mobile/Media/Photos
	chown -R mobile:mobile /var/mobile/Media/Photos
fi

exit 1
