function init() {

    var container = document.getElementById("balloonContainer");

    container.appendChild(createBallon());

}



function createBallon() {

    var balloonDiv = document.createElement("div");

    var image = document.createElement("img");

    

    image.src = "Resources/wallpaper.gif";

    balloonDiv.style.top = "-20px";

    balloonDiv.style.left = "0px";

	balloonDiv.style.position = "absolute";

    balloonDiv.style.webkitAnimationName = "float";

    balloonDiv.style.webkitAnimationDuration = "80s";

	image.style.webkitAnimationName = "drift";

	image.style.webkitAnimationDuration = "30s";

    balloonDiv.appendChild(image);



    return balloonDiv;

}



window.addEventListener("load", init, false);

