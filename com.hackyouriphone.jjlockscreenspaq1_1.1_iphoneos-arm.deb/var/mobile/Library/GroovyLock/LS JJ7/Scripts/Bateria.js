var Level = "";
var State = "";

$.ajaxSetup({
cache: false,
headers: {'Cache-Control': 'no-cache'}
});

function init() {

refreshLocationTimer = setTimeout(init, 10*1000);

jQuery.get('file:///private/var/mobile/Library/BatteryStats.txt', function(appdata) {

var myvar = appdata;
var substr = appdata.split('\n');
var Level=substr[0].split(':')[1];
var State=substr[1].split(':')[1];

if( Level > 0 && Level <= 5 ) document.getElementById("BatteryImage").src="Bateria/1.png";
if( Level > 5 && Level <= 10 ) document.getElementById("BatteryImage").src="Bateria/2.png";
if( Level > 10 && Level <= 15 ) document.getElementById("BatteryImage").src="Bateria/3.png";
if( Level > 15 && Level <= 20 ) document.getElementById("BatteryImage").src="Bateria/4.png";
if( Level > 20 && Level <= 25 ) document.getElementById("BatteryImage").src="Bateria/5.png";
if( Level > 25 && Level <= 30 ) document.getElementById("BatteryImage").src="Bateria/6.png";
if( Level > 30 && Level <= 35 ) document.getElementById("BatteryImage").src="Bateria/7.png";
if( Level > 35 && Level <= 40 ) document.getElementById("BatteryImage").src="Bateria/8.png";
if( Level > 40 && Level <= 45 ) document.getElementById("BatteryImage").src="Bateria/9.png";
if( Level > 45 && Level <= 50 ) document.getElementById("BatteryImage").src="Bateria/10.png";
if( Level > 50 && Level <= 55 ) document.getElementById("BatteryImage").src="Bateria/11.png";
if( Level > 55 && Level <= 60 ) document.getElementById("BatteryImage").src="Bateria/12.png";
if( Level > 60 && Level <= 65 ) document.getElementById("BatteryImage").src="Bateria/13.png";
if( Level > 65 && Level <= 70 ) document.getElementById("BatteryImage").src="Bateria/14.png";
if( Level > 70 && Level <= 75 ) document.getElementById("BatteryImage").src="Bateria/15.png";
if( Level > 75 && Level <= 80 ) document.getElementById("BatteryImage").src="Bateria/16.png";
if( Level > 80 && Level <= 85 ) document.getElementById("BatteryImage").src="Bateria/17.png";
if( Level > 85 && Level <= 90 ) document.getElementById("BatteryImage").src="Bateria/18.png";
if( Level > 90 && Level <= 95 ) document.getElementById("BatteryImage").src="Bateria/19.png";
if( Level > 95 && Level <= 100 ) document.getElementById("BatteryImage").src="Bateria/20.png";

document.getElementById("LevelDisplay").innerHTML = Level +"%";
document.getElementById("StateDisplay").innerHTML = State;
});
}