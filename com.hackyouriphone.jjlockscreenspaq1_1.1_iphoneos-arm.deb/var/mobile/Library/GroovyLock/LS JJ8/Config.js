/*
Configuration here !
Code by Dacal -- Modified by Schnedi  // D0 NOT REMOVE THIS LINE //
For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)
*/

var Clock = "12h";	       // choose between "12h" or "24h"
var lang = "sp";	       // (fr) for french, (de) for german, (sp) for spanish, (it) for italian, (en) for english