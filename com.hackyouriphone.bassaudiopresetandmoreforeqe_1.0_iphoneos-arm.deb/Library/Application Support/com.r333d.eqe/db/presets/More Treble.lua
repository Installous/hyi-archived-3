return {
    {
        name = "preamp",
        gain = -0.0,
    },
    {
        name = "eq",
        frequency = 31,
        Q = 1,
        gain = 0.0,
    },
    {
        name = "eq",
        frequency = 60,
        Q = 1,
        gain = -20.0,
    },
    {
        name = "eq",
        frequency = 170,
        Q = 1,
        gain = -16.658157,
    },
    {
        name = "eq",
        frequency = 310,
        Q = 1,
        gain = -12.324462,
    },
    {
        name = "eq",
        frequency = 600,
        Q = 1,
        gain = -8.262551,
    },
    {
        name = "eq",
        frequency = 1000,
        Q = 1,
        gain = -5.809587,
    },
    {
        name = "eq",
        frequency = 3000,
        Q = 1,
        gain = -1.596897,
    },
    {
        name = "eq",
        frequency = 6000,
        Q = 1,
        gain = 1.79932,
    },
    {
        name = "eq",
        frequency = 12000,
        Q = 2,
        gain = 4.014926,
    },
    {
        name = "eq",
        frequency = 14000,
        Q = 2,
        gain = 7.592908,
    },
    {
        name = "eq",
        frequency = 16000,
        Q = 2,
        gain = 12.636552,
    },
}