/* global weather twentyfour translate current width*/
(function(window, doc) {
    var dailyForecastDIV = doc.getElementById('forecastDaily'),
        hourlyForecastDIV = doc.getElementById('forecastHourly'),
        cityDIV = doc.getElementById('city'),
        conditionDIV = doc.getElementById('condition'),
        weatherIconDIV = doc.getElementById('weatherIcon'),
        percentDIV = doc.getElementById('percent'),
        tempDIV = doc.getElementById('temp'),
        highDIV = doc.getElementById('high'),
        lowDIV = doc.getElementById('low'),
        percentArray = [];

    function getAverage(array){
        var sum = 0;
        for( var i = 0; i < array.length; i++ ){
            sum += parseInt( array[i], 10 );
        }
        return Math.floor(sum/array.length);
    }

    function getHour(hour){
      var curHour;
          curHour = new Date().getHours();
          hour = curHour + hour;
          /*
            if hour is greator or equal to 24 subtract the hour.
            This will stop the overflow since we are adding hours
          */
          if(hour >= 24){
              hour = Math.abs(24 - hour);
          }
          if(!twentyfour){
              hour = (hour + 11) % 12 + 1;
          }
          hour = hour + ":00";
      return hour;
    }

    function create(typeOfForecast){
        var isDaily, forecast, count,  holder, first, second;

            isDaily = (typeOfForecast === 'daily') ? true : false;
            forecast = (isDaily) ? weather.dayForecasts : weather.hourlyForecasts;
            count = (width > 300) ? 6 : 5;

            if(isDaily){
                dailyForecastDIV.innerHTML = "";
            }else{
                count = 10;
                hourlyForecastDIV.innerHTML = "";
                percentArray = [];
            }

            for (var i = 0; i < count; i++) {
                holder = document.createElement('div');
                first = document.createElement('div');
                second = document.createElement('div');

                holder.className = 'item';
                first.className = (isDaily) ? 'icon' : 'time';
                second.className = (isDaily) ? 'lowhi' : 'percent';

                if(isDaily){
                    first.style.backgroundImage = 'url("icons/' + forecast[i].icon + '.png")';
                    second.innerHTML = '<span>'+forecast[i].high+'&deg;</span>/<span>'+forecast[i].low+'&deg;</span>';
                }else{
                    first.innerHTML = getHour(forecast[i].hourIndex);
                    second.innerHTML = forecast[i].percentPrecipitation + "%";
                    percentArray.push(Number(forecast[i].percentPrecipitation));
                }

                holder.appendChild(first);
                holder.appendChild(second);

                if(isDaily){
                    dailyForecastDIV.appendChild(holder);
                }else{
                    hourlyForecastDIV.appendChild(holder);
                }
            }
            if(!isDaily){
                percentDIV.innerHTML = "Chance of rain " + getAverage(percentArray) + "%";
            }
    }

    function refreshWeatherInfo(){
        tempDIV.innerHTML = weather.temperature;
        highDIV.innerHTML = weather.high + "&deg;";
        lowDIV.innerHTML = weather.low + "&deg;";
        cityDIV.innerHTML = weather.city;
        conditionDIV.innerHTML = translate[current].condition[weather.conditionCode];
        weatherIconDIV.style.backgroundImage = 'url("icons/'+weather.conditionCode + '.png")';
    }

    function forecast() {
        var forecast = {};
        forecast.loadInfo = function() {
            create('daily');
            create('hourly');
        };
        return forecast;
    }

    function weatherInfo(){
        var weatherInfo = {};
        weatherInfo.loadInfo = function(){
            refreshWeatherInfo();
        };
        return weatherInfo;
    }
    window.forecast = forecast();
    window.weatherInfo = weatherInfo();
}(window, document));