(function(window, doc) {
    var bottom = doc.getElementById('bottom'),
        daily = doc.getElementById('forecastDaily'),
        hourly = doc.getElementById('forecastHourly'),
        moving = false;

        function toggle(){
            var dailyState, hourlyState;
            if(!moving){
                if(daily.style.display == 'block'){
                    dailyState = 'none';
                    hourlyState = 'block';
                }else{
                    dailyState = 'block';
                    hourlyState = 'none';
                }
                daily.style.display = dailyState;
                hourly.style.display = hourlyState;
            }
            moving = false;
        }

        function isMoving(){
            moving = true;
        }

        bottom.addEventListener('touchend', toggle, false);
        bottom.addEventListener('touchmove', isMoving, false);
}(window, document));