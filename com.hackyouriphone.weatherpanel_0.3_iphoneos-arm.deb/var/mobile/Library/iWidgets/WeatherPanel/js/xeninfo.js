/* eslint no-empty: "off", curly: "error", no-unused-vars: "off" */
function mainUpdate(type) {
    if (type == "weather") {
        window.weatherInfo.loadInfo();
        window.forecast.loadInfo();
    } else if (type == "statusbar") {
    } else if (type == "battery") {
    } else if (type == "reminders") {
    } else if (type == "events") {
    } else if (type == "music") {
    } else if (type == "system") {
    } else if (type == "alarm") {
    }
}