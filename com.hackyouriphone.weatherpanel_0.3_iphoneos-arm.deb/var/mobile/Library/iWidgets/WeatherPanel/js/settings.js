(function(window, doc) {
	
	//Options.plist
	// var width = 300;
	// var bgcolor = "black";
	// var	borderradius = 25;

    var container = doc.getElementById('container');
        container.style.width = width + "px";
        container.style.backgroundColor = bgcolor;
        container.style.borderRadius = borderradius + "px";
}(window, document));