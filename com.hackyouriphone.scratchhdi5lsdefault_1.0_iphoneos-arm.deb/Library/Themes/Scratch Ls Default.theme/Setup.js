
/* *************************************** */

/* **************** CLOCK **************** */

//Toggles twelve and twenty-four hour time.
// false = 12h time format
// true = 24h time format

var twentyFourHourTime = false;


/* ************* LANGUAGE **************** */
//Choose Languages :
// English = EN
// French = FR
// Italian = IT
// Spanish = ES
// German = DE
// Russian = RU

var language = 'EN';


/* ********* Configure Your Weather Widget here ********* */
/* Step 1 - Find YOUR city code (locale) here : http://www.edg3.co.uk/snippets/weather-location-codes/

Some Examples :
USNY0996 = NYC, US
USCA0638 = LA, US
USCA0987 = Frisco, US
FRXX0076 = Paris, FR
CAXX0301 = Montreal, CA
UKXX0085 = London, UK
ITXX0042 = Milan, IT
*/

/* Step 2 - Then enter your city code here */
var locale = "FRXX3755" 


/* *************************************** */


/*  *********** Extra Options ************************* */

/* Use Celsius or not */
var isCelsius = true

/* Use Real Feel Temperature or not */
var useRealFeel = false

/* Minutes between updates */
var updateInterval = 15


/* ****************************************************** */
