/* Copyright © 0neguy Inc. 2019 */

var $ = document;
var d = new Date();

function debug() {
    document.getElementById("debug").innerHTML = ""
    document.getElementById("debug").innerHTML += "isTime: " + isTime + "<br>"
    document.getElementById("debug").innerHTML += "isDate: " + isDate + "<br>"
    document.getElementById("debug").innerHTML += "widgetSize: " + widgetSize + "<br>"
    document.getElementById("debug").innerHTML += "dateColor: " + dateColor + "<br>"
    document.getElementById("debug").innerHTML += "clockColor: " + clockColor + "<br>"
    document.getElementById("debug").innerHTML += "dateShadow: " + dateShadow + "<br>"
    document.getElementById("debug").innerHTML += "clockShadow: " + clockShadow + "<br>"
    document.getElementById("debug").innerHTML += "timeSize: " + timeSize + "<br>"
    document.getElementById("debug").innerHTML += "dateSize: " + dateSize + "<br>"
    document.getElementById("debug").innerHTML += "isDebugMode: " + isDebugMode + "<br>"
}

function prefs() {
    if (isDebugMode === 1) {
        debug();
        document.getElementById("debug").style.display = "block";
    }

    let time = document.getElementById("time")
    let date = document.getElementById("date")
    let clock = document.getElementById("clock")

    time.style.color = clockColor;
    date.style.color = dateColor;

    time.style.textShadow = clockShadow;
    date.style.textShadow = dateShadow;

    time.style.fontSize = timeSize;
    date.style.fontSize = dateSize;

    clock.style.transform = "scale(" + widgetSize + ")";
}

function time() {
    let time = document.getElementById("time")
    let date = document.getElementById("date")
    let dayStr = d.getDay();
    let monthStr = d.getMonth();

    let dayText;
    if (dayStr === 1) {
        dayText = "Monday, "
    } else if (dayStr === 2) {
        dayText = "Tuesday, ";
    } else if (dayStr === 3) {
        dayText = "Wednesday, ";
    } else if (dayStr === 4) {
        dayText = "Thursday, ";
    } else if (dayStr === 5) {
        dayText = "Friday, ";
    } else if (dayStr === 6) {
        dayText = "Saturday, ";
    } else if (dayStr === 0) {
        dayText = "Sunday, ";
    };

    let monthText;
    if (monthStr === 0) {
        monthText = "Jan";
    } else if (monthStr === 1) {
        monthText = "Feb";
    } else if (monthStr === 2) {
        monthText = "Mar";
    } else if (monthStr === 3) {
        monthText = "Apr";
    } else if (monthStr === 4) {
        monthText = "May";
    } else if (monthStr === 5) {
        monthText = "Jun";
    } else if (monthStr === 6) {
        monthText = "Jul";
    } else if (monthStr === 7) {
        monthText = "Aug";
    } else if (monthStr === 8) {
        monthText = "Sep";
    } else if (monthStr === 9) {
        monthText = "Oct";
    } else if (monthStr === 10) {
        monthText = "Nov";
    } else if (monthStr === 11) {
        monthText = "Dec";
    };
    if (isTime === 1) {
        time.innerHTML = d.getHours() + ":" + d.getMinutes();
    }
    if (isDate === 1) {
        date.innerHTML = dayText + d.getDate() + " " + monthText;
    }
    if (isDate === 0 && isTime === 0) {
        time.innerHTML = "why.";
        date.innerHTML = "Did you turn off date and time...<br>like wtf<br> Nothing is supposed to be here but i want to let you know that what your doing makes no sense..."
    }
}

document.body.onload = function () {
    time();
    prefs();
}

setTimeout(function () {
    time();
}, 10000)