var Clock = "24h"; // Select Time Format"12h" or "24h"Saat Formati Sec 12 veya 24 Saat
var Lang = "tr"; // "Select Language Widget icin Kullanilacak Dili Sec "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh" "tr"
