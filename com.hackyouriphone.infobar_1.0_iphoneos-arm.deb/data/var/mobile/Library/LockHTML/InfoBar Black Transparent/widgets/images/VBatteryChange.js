(function() {
    var div = document.createElement("div"),
        bottomBack = document.createElement('div'),
        bottomInside = document.createElement('div'),
        top = document.createElement('div'),
        getVBattery;

    div.id = 'VBatteryChange';
    div.style.cssText = 'width:38px;height:73px;position:absolute;top:0;left:0;background-color:transparent;font-family:helvetica;';

    bottomBack.style.cssText = 'position:absolute;top:20px;left:3px;width:30px;height:50px;background-color:transparent;border:1px solid white;';
    bottomInside.style.cssText = 'pointer-events:none;position:absolute;top:57px;left:6px;width:26px;height:1px;background-color:white;';
    bottomInside.id = 'VBatteryChangeInside';
    top.style.cssText = 'position:absolute;top:14px;left:9px;width:18px;height:6px;background-color:transparent;border:1px solid white;border-bottom:none;';

    div.appendChild(bottomInside);
    div.appendChild(bottomBack);
    div.appendChild(top);

    document.getElementById('screenElements').appendChild(div);

    getVBattery = function() {
        if (typeof globalBattery !== 'undefined') {
            document.getElementById('VBatteryChangeInside').style.height = Math.round((cycript.batteryPercent() / 100) * 46);
            if (cycript.getCharging() === "Charging") {
                document.getElementById('VBatteryChangeInside').style.backgroundColor = "limegreen";           
            }
            else {    
                if (cycript.batteryPercent() < 21) {
                    document.getElementById('VBatteryChangeInside').style.backgroundColor = "red";
                } else if (cycript.batteryPercent() < 31) {
                    document.getElementById('VBatteryChangeInside').style.backgroundColor = "#fcdd03";
                } else {
                    document.getElementById('VBatteryChangeInside').style.backgroundColor = "white";
                }
            }
        } else {
            document.getElementById('VBatteryChangeInside').style.height = Math.round((40 / 100) * 31);
            document.getElementById('VBatteryChangeInside').style.backgroundColor = "#fcdd03";
        }
        setTimeout(getVBattery, 5000);
    };
    getVBattery();

}());