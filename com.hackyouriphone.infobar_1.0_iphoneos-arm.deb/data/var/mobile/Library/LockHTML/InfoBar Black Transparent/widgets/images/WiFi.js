(function() {
    var div = document.createElement("div"),
        baseCircle = document.createElement('span'),
        ring1 = document.createElement('span'),
        ring2 = document.createElement('span'),
        ring3 = document.createElement('span'),
        textX = document.createElement('p'),
        getWifiSignal;
       
    div.id = "WiFi";
    div.style.cssText = 'width:30px;height:30px;position:absolute;top:0;left:0;background-color:transparent;font-family:helvetica;color:white;';
    baseCircle.style.cssText = 'position:absolute;pointer-events:none;left:25px;top:25px;width:5px;height:5px;background-color:#777; border-radius:100%;';
    baseCircle.id = 'baseCircle'
    ring1.style.cssText = 'position:absolute;pointer-events:none;top:19px;left:19px;width:18px;height:18px;border-radius:100%;border:2px solid transparent;border-top-color:#777;transform:rotate(315deg);';
    ring2.style.cssText = 'position:absolute;pointer-events:none;top:13px;left:13px;width:30px;height:30px;border-radius:100%;border:2px solid transparent;border-top-color:#777;transform:rotate(315deg);';
    ring3.style.cssText = 'position:absolute;pointer-events:none;top:7px;left:7px;width:43px;height:43px;border-radius:100%;border:2px solid transparent;border-top-color:#777;transform:rotate(315deg);';
    ring1.id = 'ring1'
    ring2.id = 'ring2'
    ring3.id = 'ring3'
    textX.style.cssText = 'position:absolute;pointer-events:none;top:-13px;left:2px;color:currentColor;font-size:small;';
    textX.id = 'nowifi'
    
    
    div.appendChild(baseCircle);
    div.appendChild(ring1);
    div.appendChild(ring2);
    div.appendChild(ring3);
    div.appendChild(textX);



    document.getElementById('screenElements').appendChild(div);
    getWifiSignal = function() {
        if (typeof globalBattery !== 'undefined') {
            document.getElementById('nowifi').innerHTML = "";
            document.getElementById('baseCircle').style.backgroundColor = "#777";
            document.getElementById('ring1').style.borderTopColor = "#777";
            document.getElementById('ring2').style.borderTopColor = "#777";
            document.getElementById('ring3').style.borderTopColor = "#777";
            
            if (cycript.getWifi() > 80) {
            document.getElementById('baseCircle').style.backgroundColor = "currentColor";
            document.getElementById('ring1').style.borderTopColor = "currentColor";
            document.getElementById('ring2').style.borderTopColor = "currentColor";
            document.getElementById('ring3').style.borderTopColor = "currentColor";

            }
            else if (cycript.getWifi() > 50) {
            document.getElementById('baseCircle').style.backgroundColor = "currentColor";
            document.getElementById('ring1').style.borderTopColor = "currentColor";
            document.getElementById('ring2').style.borderTopColor = "currentColor";
            }
            else if (cycript.getWifi() > 30) {
                document.getElementById('baseCircle').style.backgroundColor = "currentColor";
                document.getElementById('ring1').style.borderTopColor = "currentColor";
            }
            else if (cycript.getWifi() > 10) {
                document.getElementById('baseCircle').style.backgroundColor = "currentColor";
            }
            else if (cycript.getWifi() < 5) {
            document.getElementById('nowifi').innerHTML = "&#10006;";


            }
        } else {

         document.getElementById('baseCircle').style.backgroundColor = "currentColor";
            document.getElementById('ring1').style.borderTopColor = "currentColor";
            document.getElementById('ring2').style.borderTopColor = "currentColor";   

            
        }
        setTimeout(getWifiSignal, 5000);
    };
    getWifiSignal();
}());