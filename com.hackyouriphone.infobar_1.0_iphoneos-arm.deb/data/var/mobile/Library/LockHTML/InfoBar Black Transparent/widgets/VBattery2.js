(function () {
    var div = document.createElement("div"),
        bottomBack = document.createElement('div'),
        bottomInside = document.createElement('div'),
        top = document.createElement('div'),
        getVBattery;

    div.id = 'VBattery2';
    div.style.cssText = 'width:80px;height:70px;position:absolute;top:0;left:0px;background-color:transparent;font-family:helvetica;';

    bottomBack.style.cssText = 'position:absolute;top:20px;left:3px;width:50px;height:30px;background-color:transparent;border:1px solid white;pointer-events:none;';
    bottomInside.style.cssText = 'position:absolute;top:23px;left:5px;height:27px;width:1px;background-color:white;-webkit-transform:rotate(180deg);pointer-events:none;';
    bottomInside.id = 'VBatteryInner';
    top.style.cssText = 'position:absolute;top:26px;left:54px;width:6px;height:18px;background-color:transparent;border:1px solid white;border-left:none;pointer-events:none;';

    div.appendChild(bottomInside);
    div.appendChild(bottomBack);
    div.appendChild(top);

    document.getElementById('screenElements').appendChild(div);

    getVBattery = function () {
        try {
            document.getElementById('VBatteryInner').style.width = Math.round((injectedSystem.battery / 100) * 47);
        }catch(err) {
            document.getElementById('VBatteryInner').style.width = Math.round((50 / 100) * 47);
        }
        setTimeout(getVBattery, 5000);
    };
    getVBattery();

}());