var CustomGreeting = "John";
var CustomGreetingColour = "#d01925";
var CustomGreetingBackgroundColour = "#d01925";
var CustomGreetingTextColour = "White";
var ShowAnimation = true;
var ShowWidgets = true;
