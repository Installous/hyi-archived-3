For Celcius:

Go into the /Widgets/HTC folder, and delete the functions.js file, and rename functionsCEL.js to functions.js

-
August 25, 2011.