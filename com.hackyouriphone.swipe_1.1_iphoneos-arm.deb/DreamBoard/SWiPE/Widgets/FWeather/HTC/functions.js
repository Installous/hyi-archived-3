/*

==========================
Endroid Weather Widget
==========================

Wynd.

Edited by Abhishek Joshi
2011
www.abhishekj.serveftp.net

*/
//localStorage.setItem("zip", 77429)
window.onload = onLoad;
var MiniIcons =["tstorm3","tstorm3","tstorm3","tstorm3","tstorm3","sleet","sleet","sleet","sleet","showers","sleet","showers","showers","snow1","snow1","snow1","snow1","hail","sleet","fog","fog","fog","fog","cloudy1","cloudy1","cloudy1","cloudy1","cloudy1_night","cloudy1","cloudy1_night","cloudy1","sunny_night","sunny","sunny_night","sunny","hail","sunny","tstorm3","tstorm3","tstorm3","tstorm3","snow1","snow1","snow1","cloudy1","storm1","snow1","tstorm3","dunno"];
var locale;
var updateInterval = 10;
var postal;
document.ontouchmove = function(event) {
	event.preventDefault();
}
function getDate(){
	//gets the date
	var ma = "Jan Feb March April May June July Aug Sep Oct Nov Dec".split(/\s/);
	var da = "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(/\s/);
	return da[new Date().getDay()] + ", " + ma[new Date().getMonth()] + " " + (new Date().getDate()<10?("0" + new Date().getDate()):new Date().getDate());
}
function getTime(){
	//gets the time
	var d = new Date();
	return (d.getHours()>=10?(d.getHours()>12?((d.getHours()-12)>=10?(d.getHours()-12):("0"+(d.getHours()-12))):d.getHours()):"0"+d.getHours())+":"+(d.getMinutes()>=10?d.getMinutes():"0"+d.getMinutes())+(d.getHours()>=12?"PM":"AM");
}
function updateClock(){
	//updates the flip clock
	var s = getTime();
	if(s.charAt(0)=='0'){
		document.getElementById("clock1").innerHTML = "";
	}else{
		document.getElementById("clock1").innerHTML = "" + "";
	}
	document.getElementById("clock2").innerHTML = "" + "";
	var d = new Date();
	setTimeout("updateClock()",1000*(60-(d.getSeconds())));
}
function checkZip(){
	//see if zipcode is still the same, otherwise reload the weather
	if(localStorage.getItem("zip")!=locale){
		onLoad();
	}else{
		setTimeout(checkZip, 500);
	}
}
function onLoad(){
	//loads all images of the clock
	if(localStorage.getItem("zip")==null)
		//if no zip code, then try again later
		setTimeout(onLoad, 500);
	else{
		//sets based on the localstorage cache
		document.getElementById("desc").innerText=localStorage.getItem("cachedesc");
		document.getElementById("temp").innerText=localStorage.getItem("cachetemp");
		//sets zipcode to the localstorage value
		locale= localStorage.getItem("zip");
		//gets the weather
		validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal);
		updateClock();
		//animation
		setTimeout("document.getElementById('icon').style.webkitTransform='scale(1)';",500);
		setTimeout("document.getElementById('icon').style.opacity=1;",500);
		//checks to see if the zip was changed
		checkZip();
	}
}
function setPostal(obj){	
	if (obj.error == false){
		if(obj.cities.length > 0){
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%");
			weatherRefresherTemp();
		}else{
		}
	}else{
		setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));
	}
}
function dealWithWeather(obj){
	document.getElementById("desc").innerText=obj.description;
	document.getElementById("temp").innerText=obj.temp+"�F";
	//stores cache values
	localStorage.setItem("cachedesc", obj.description);
	localStorage.setItem("cachetemp", (obj.temp+"�F"));
}
function weatherRefresherTemp(){
	fetchWeatherData(dealWithWeather,postal);
	setTimeout(onLoad, 60*1000*updateInterval);
}
function constructError (string)
{
	return {error:true, errorString:string};
}
function findChild (element, nodeName)
{
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
		if (child.nodeName == nodeName)
			return child;
	}
	return null;
}
function fetchWeatherData (callback, zip)
{
	url="http://weather.yahooapis.com/forecastrss?u=f&p=";
	var xml_request = new XMLHttpRequest();
	xml_request.onload = function(e) {xml_loaded(e, xml_request, callback);}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url+zip);
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null); 
	return xml_request;
}
function xml_loaded (event, request, callback)
{
	if (request.responseXML)
	{
		var obj = {error:false, errorString:null};
		var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
		obj.realFeel = findChild(effectiveRoot, "yweather:wind").getAttribute("chill"); 	
		conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
		obj.temp = conditionTag.getAttribute("temp");
		obj.description = conditionTag.getAttribute("text"); 
		var div = document.createElement("div");
		div.innerHTML = request.responseText;
		var list = div.getElementsByTagName("yweather:forecast");
		callback (obj); 
	}else{
		callback ({error:true, errorString:"XML request failed. no responseXML"});
	}
}
function validateWeatherLocation (location, callback)
{
	var obj = {error:false, errorString:null, cities: new Array};
	obj.cities[0] = {zip: location};
	callback (obj);
}