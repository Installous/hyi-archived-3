const hoursE = document.querySelectorAll(".hours .digit");
const minutesE = document.querySelectorAll(".minutes .digit");
const secondsE = document.querySelectorAll(".seconds .digit");

const addDataValue = (elemList, values) => {
    values.forEach((value, index) => {
        elemList[index].dataset.value = `d${value}`;
    });
};

const valuesToArray = (value) => {
    if (value < 10) {
        return [0, value];
    } else {
        const s = value.toString().split("");
        return [parseInt(s[0]), parseInt(s[1])];
    }
};

const scale = (value, in_min, in_max, out_min, out_max) => {
    return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

const setHue = (value) => {
    document.documentElement.style
        .setProperty('--hue', `${scale(value, 0, 60, 0, 360)}deg`);
}

setInterval(() => {
    const now = new Date();
    const hours = now.getHours() < 13 ? now.getHours() : now.getHours() - 12;
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();

    addDataValue(hoursE, valuesToArray(hours));
    addDataValue(minutesE, valuesToArray(minutes));
    addDataValue(secondsE, valuesToArray(seconds));

    setHue(seconds);
}, 1000);
