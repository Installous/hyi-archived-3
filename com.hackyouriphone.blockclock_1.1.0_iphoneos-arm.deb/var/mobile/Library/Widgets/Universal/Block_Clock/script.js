$(document).ready(function () {
    var digitOne = [2, 6, 7, 12, 17, 22];
    var digitTwo = [1, 2, 3, 8, 11, 12, 13, 16, 21, 22, 23];
    var digitThree = [1, 2, 3, 8, 11, 12, 13, 18, 21, 22, 23];
    var digitFour = [1, 3, 6, 8, 11, 12, 13, 18, 23];
    var digitFive = [1, 2, 3, 6, 11, 12, 13, 18, 21, 22, 23];
    var digitSix = [1, 2, 3, 6, 11, 12, 13, 16, 18, 21, 22, 23];
    var digitSeven = [1, 2, 3, 8, 13, 18, 23];
    var digitEight = [1, 2, 3, 6, 8, 11, 12, 13, 16, 18, 21, 22, 23];
    var digitNine = [1, 2, 3, 6, 8, 11, 12, 13, 18, 21, 22, 23];
    var digitZero = [1, 2, 3, 6, 8, 11, 13, 16, 18, 21, 22, 23];

    var digits = [
        digitZero,
        digitOne,
        digitTwo,
        digitThree,
        digitFour,
        digitFive,
        digitSix,
        digitSeven,
        digitEight,
        digitNine
    ];

    setInterval(function () {
        var time = convertDateToObject(new Date());
        $('.hoursFirst .box').each(function (index, element) {
            digits[time.hoursFirst].includes(index)
                ? $(element).removeClass('active')
                : $(element).addClass('active');
        });
        $('.hoursLast .box').each(function (index, element) {
            digits[time.hoursLast].includes(index)
                ? $(element).removeClass('active')
                : $(element).addClass('active');
        });

        $('.minutesFirst .box').each(function (index, element) {
            digits[time.minutesFirst].includes(index)
                ? $(element).removeClass('active')
                : $(element).addClass('active');
        });
        $('.minutesLast .box').each(function (index, element) {
            digits[time.minutesLast].includes(index)
                ? $(element).removeClass('active')
                : $(element).addClass('active');
        });

        $('.secondsFirst .box').each(function (index, element) {
            digits[time.secondsFirst].includes(index)
                ? $(element).removeClass('active')
                : $(element).addClass('active');
        });

        $('.secondsLast .box').each(function (index, element) {
            digits[time.secondsLast].includes(index)
                ? $(element).removeClass('active')
                : $(element).addClass('active');
        });
    }, 1000);
});

function convertDateToObject(dateParam) {
    var seconds = dateParam.getSeconds();
    var minutes = dateParam.getMinutes();
    var hours = dateParam.getHours() < 13 ? dateParam.getHours() : dateParam.getHours() - 12;
    return {
        secondsFirst: parseInt(seconds / 10),
        secondsLast: parseInt(seconds % 10),
        minutesFirst: parseInt(minutes / 10),
        minutesLast: parseInt(minutes % 10),
        hoursFirst: parseInt(hours / 10),
        hoursLast: parseInt(hours % 10)
    };
}
