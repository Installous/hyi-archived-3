function date_time_lock(id)
{
        date = new Date;
        month = date.getMonth();
        months = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
        d = date.getDate();
        day = date.getDay();
        days = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
        h = date.getHours();
		        if(h>12)
        {
        				h = h-12;
        }
				if(h<10)
        {
                h = h;
        }
				if(h<1)
		{
				h = 12;
		}
        m = date.getMinutes();
        if(m<10)
        {
                m = "0"+m;
        }
        result = days[day]+', '+months[month]+' '+d
        result2 = h+':'+m;
        document.getElementById('heure').innerHTML = result2;
        document.getElementById('date').innerHTML = result;
        setTimeout('date_time("'+id+'");','1000');
        return true;
}