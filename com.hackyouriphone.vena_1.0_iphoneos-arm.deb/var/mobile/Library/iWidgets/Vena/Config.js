var Scale = "1"; 
var Clock = "13h"; // choose between "12h" or "24h"
var refreshrate = 10; // update interval of weather, in minutes
var IconWeather = "1"; // 1=White, 2=Black
var HideWeather = false; 
var TextColor = "azure"; 
var FrameColor = "purple"; 
